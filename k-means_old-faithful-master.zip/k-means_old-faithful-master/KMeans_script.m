% KMeans_script
K = 5;
filename = 'scaledfaithful.txt';
runKMeans(K,filename)