# k-means-old-faithful
this is the K-means algorithm in Matlab language using the old faithful dataset
dataset from http://www.stat.cmu.edu/~larry/all-of-statistics/=data/faithful.dat

To learn more about the program implementation, please read my CSDN blog
http://blog.csdn.net/liu1194397014/article/details/52844997
